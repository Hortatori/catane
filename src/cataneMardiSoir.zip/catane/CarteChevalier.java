package catane;

public class CarteChevalier extends Carte {

	@Override
	protected void actionCarte() {
		// TODO Auto-generated method stub

	}

}