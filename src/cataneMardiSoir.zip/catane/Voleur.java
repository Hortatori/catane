package catane;

import java.util.ArrayList;
import java.util.Scanner;

public class Voleur {
    private Case caseVoleur;
    private Partie partie;
    private int quantiteDef;

    public Voleur(Partie p) {
        this.partie = p;
        VoleurPanel voleurIG = new VoleurPanel(p.plateau);
        this.caseVoleur = p.plateau.desert;
    }

    public void setCase(Case c) {
        this.caseVoleur = c;
    }

    public Case getCase() {
        return this.caseVoleur;
    }

    public void deplaceVoleur(Case c) {
        this.caseVoleur.setStatutVoleur(false);
        c.setStatutVoleur(true);
        this.caseVoleur = c;
    }

    // si dé == 7 dans Partie / IG
    public void VoleurArrive(ArrayList<Joueur> joueurs, Joueur leader) {
        if (!leader.partie.plateau.graphique) {
            System.out.println(
                    "le voleur arrive! personne ne profite des ressources \ntous les joueur.euses qui ont plus de 6 ressources doivent defausser la moitie de leur main");
            for (Joueur joueur : joueurs) {
                if (joueur.totalR >= 7) {
                    int aDefausser = joueur.totalR / 2;
                    System.out.println(
                            "vous êtes assez riches pour être volé, vous avez " + joueur.totalR + " ressources");
                    while (aDefausser > 0) {
                        System.out.println(
                                "vous devez defausser " + aDefausser + " parmi vos ressources : " + joueur.toString());
                        demanderRessource(joueur);
                        aDefausser = aDefausser - quantiteDef;

                    }
                } else {
                    System.out.println(joueur.getNom() + " vous n'êtes pas assez riche pour être volé");
                }

            }
            int[] coord = this.partie.ij.getCoord("Joueur " + leader.getNom()
                    + ", vous decidez quelle sera la prochaine place du Voleur! Donnez des coordonnées");

            VoleurPart(coord);
            // TODO : leader vole une ressource au hasard chez un joueur qui a une
            // ville/colonie sur le bord de la nouvelle case du voleur
        } else {
            // affichage : voleurIG fait des choses OU BIEN on affiche tout en même temps
            // selon le bool
        }
    }

    public void VoleurPart(int[] coord) {
        int x = coord[0];
        int y = coord[1];

        this.deplaceVoleur(partie.plateau.plateauC[x][y]);
    }

    public void demanderRessource(Joueur joueur) {
        diviserAction(" Sélectionnez une ressource :\n 1 : Bois\n 2 : Laine \n 3 : Pierre \n 4 : Ble \n 5 : Argile",
                joueur);
        Scanner sc = new Scanner(System.in);
        int ressource = sc.nextInt();
        diviserAction(" choisissez une quantité a défausser", joueur);
        int quantite = sc.nextInt();
        this.quantiteDef = quantite;

        // System.out.println(
        // " Sélectionnez une ressource :\n 1 : Bois\n 2 : Laine \n 3 : Pierre \n 4 :
        // Champ \n 5 : Argile");
        // Scanner sc = new Scanner(System.in);
        // int ressource = sc.nextInt();
        // System.out.println(
        // " choisissez une quantité a défausser");
        // int quantite = sc.nextInt();

        switch (ressource) {
            case 1:
                joueur.getR().payBois(quantite);
                break;

            case 2:
                joueur.getR().payMouton(quantite);
                break;

            case 3:
                joueur.getR().payPierre(quantite);
                break;

            case 4:
                joueur.getR().payBle(quantite);
                break;

            case 5:
                joueur.getR().payArgile(quantite);
                break;

            default:
                System.out.println("vous devez donner un entier entre 1 et 5");
                demanderRessource(joueur);

        }
    }

    public void diviserAction(String s, Joueur leader) {
        if (leader.partie.plateau.graphique) {
            leader.partie.view.Communicate(s);
        } else {
            System.out.println(s);
        }

    }
}
