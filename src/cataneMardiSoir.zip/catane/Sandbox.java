package catane;

import java.awt.Color;

import javax.swing.JFrame;

public class Sandbox {

	public static void main(String[] args) {
		System.out.println("bouc");
		// Plateau p = new Plateau();
		//// p.afficherPlateau();
		//// p.afficherPlateau2();
		// p.afficherPlateau3();
		// Scanner sc = new Scanner(System.in);
		// Partie p = new Partie();
		// p.plateau.afficherPlateau3();
		// Plateau p = new Plateau();
		// p.afficherPlateau();
		System.out.println("voo");

		javax.swing.SwingUtilities.invokeLater(
				new Runnable() {
					public void run() {

						// Vue v = new Vue(p.vp);
						// Joueur J = new Joueur ("marielle") ;
						// J.setCouleur(Color.BLUE);
						// v.updateJoueur(J);
						Partie p = new Partie();
						// Joueur j = new Joueur ();
						// j.setCouleur(Color.BLUE) ;
						// Plateau plateau = new Plateau();
						// VuePlateau vp = new VuePlateau(plateau) ;
						// JFrame f = new JFrame();
						// f.setSize(700,700);
						// f.add(vp);
						// f.setVisible(true);
						// vp.drawColonie(j, plateau.plateauS[0][0]);
						// vp.drawColonie(j, plateau.plateauS[0][1]);
						// vp.drawColonie(j, plateau.plateauS[0][2]);
						// vp.drawColonie(j, plateau.plateauS[0][4]);
						// f.setVisible(true);
						// p.debug();
						// Joueur J = new Joueur ("edfr",p) ;
						// System.out.println("voo") ;
						// p.view.drawColonie(J, 0, 0) ;
						// //Vue v = new Vue();
						// Sommet s = new Sommet (3, 2) ;
						// Sommet s2 = new Sommet (0, 3) ;
						// Route r = new Route (s, s2);
						// v.vp.drawRoute(J, r);
						// v.vp.drawColonie(J, s2);
						// v.vp.drawVille(J, s);
					}
				});

	}

}
