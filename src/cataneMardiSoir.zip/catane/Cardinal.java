package catane;

public enum Cardinal {
    N, S, E, O
}
