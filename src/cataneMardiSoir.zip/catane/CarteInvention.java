package catane;

public class CarteInvention extends Carte {

	@Override
	protected void actionCarte() {
		// TODO Auto-generated method stub

	}

}