package catane;

public enum Paysage {

	DESERT, FORET, MONTAGNE, COLLINE, PRE, CHAMP

}
