//package catane;
//
//public class CarteProgres extends Carte {
//
//}

// on ne va pas utiliser 